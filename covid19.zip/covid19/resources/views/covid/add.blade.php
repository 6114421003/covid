@extends("layouts.master")
@section('title') Covid-19 @stop
@section('content')
<br>
<center><h1>ยอดผู้ติดเชื้อ Covid-19 ในจังหวัดจันทบุรี</h1>
<br>
<div class="panel panel-default">
    {!! Form::open(array('action' => 'CovidController@insert', 'method'=>'post', 'enctype' => 'multipart/form-data')) !!}

    @if($errors->any())
    <div class="alert alert-danger">
        @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
    </div>
    @endif

    <div class="panel-heading">
        <div class="panel-title"><h3>เพิ่มข้อมูล</h3></div>
    </div>
    <div class="panel-body">
        <table>
        <tr>
                <td>{{ Form::label('dis', 'อำเภอ') }}</td>
                <td>{{ Form::text('dis', Request::old('dis'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('ndis', 'จำนวนคนที่อยู่ในอำเภอ') }}</td>
                <td>{{ Form::text('ndis', Request::old('ndis'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('piwc', 'ติดเชื้อสะสม') }}</td>
                <td>{{ Form::text('piwc', Request::old('piwc'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('cure', 'รักษาหาย') }}</td>
                <td>{{ Form::text('cure', Request::old('cure'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('vp', 'คนฉีดวัคซีน') }}</td>
                <td>{{ Form::text('vp', Request::old('vp'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('nvp', 'คนที่ยังไม่ได้ฉีดวัคซีน') }}</td>
                <td>{{ Form::text('nvp', Request::old('nvp'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('die', 'เสียชีวิต') }}</td>
                <td>{{ Form::text('die', Request::old('die'), ['class' => 'form-control']) }}</td>
            </tr>
        </table>
    </div><br>
    <div class="panel-footer">
    <a href="http://127.0.0.1:8000/covid"button type="button" class="btn btn-danger">ยกเลิก</button></a>    
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    {!! Form::close() !!}
</div>
</center>


@stop
