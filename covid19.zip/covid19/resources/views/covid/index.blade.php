@extends("layouts.master")
@section('title') Covid-19 @stop
@section('content')

<br>
<center><h1>ยอดผู้ติดเชื้อ Covid-19 ในจังหวัดจันทบุรี</h1>   </center>
<br>


<div class="panel panel-default">
<center>
    <a href="{{ URL::to('covid/edit') }}" class="btn btn-success pull-right"><i class="fa fa-plus"></i> เพิ่มข้อมูล</a>
        <form action="{{ URL::to('covid/search') }}" method="post" class="form-inline">
            {{ csrf_field() }}
            
         <input  type="text" name="q" class="form-control" placeholder="พิมพ์ชื่อเมืองที่ต้องการค้นหา">
            <button type="submit" class="btn btn-outline-primary"><i class="fa fa-search"></i> ค้นหา</button>
        </form>
     
     
    </div>
 

    <table class="table table-bordered table-striped table-hover">
    
        <thead>
        <br>
        <tr>
            <td>ลำดับ</td>
            <td>อำเภอ </td>
            <td>จำนวนคนที่อยู่ในอำเภอ</td>
            <td>คนติดโควิด</td>
            <td>รักษาหาย</td>
            <td>คนฉีดวัคซีน </td>
            <td>คนที่ยังไม่ได้ฉีดวัคซีน </td>
            <td>เสียชีวิต </td>
        </tr>
        </thead>
        <tbody>
            @foreach($covids as $p)
            <tr>
                <td>{{ $p->id }}</td>
                <td>{{ $p->dis }}</td>
                <td>{{ $p->ndis }}</td>
                <td>{{ $p->piwc }}</td>
                <td>{{ $p->cure }}</td>
                <td>{{ $p->vp }}</td>
                <td>{{ $p->nvp }}</td>
                <td>{{ $p->die }}</td>
                <td>
                <a href="{{ URL::to('covid/edit/'.$p->id) }}" class="btn btn-warning"><i class="fa fa-pencil"></i>แก้ไข</a>
                    <a href="#" class="btn btn-danger btn-delete" id-delete="{{ $p->id }}"><i class="fa fa-trash-o"></i> ลบ</a>
                </td>
                <script>
                    $('.btn-delete').on('click', function() {
                        if(confirm("คุณต้องการลบข้อมูลหรือไม่?")) {
                            var url = "{{ URL::to('covid/remove') }}" + '/' + $(this).attr('id-delete');
                            window.location.href = url;
                        }
                        
                    });
                </script>
            </tr>
            
            @endforeach
        </tbody>
        
    </table>

    {{ $covids->links() }}
            <br>
   <center>
   <a href="http://127.0.0.1:8000/covid"button type="button" class="btn btn-outline-info"><i class="fas fa-home"></i>หน้าแรก</button></a>    
   <a href="covidJS"button type="button" class="btn btn-danger"><i class="fas fa-shield-virus"></i>ยอดสะสมแต่ละอำเภอ</button></a>
   <a href="covid3JS"button type="button" class="btn btn-danger">เสียชีวิต</button></a> 
   <a href="covid2JS"button type="button" class="btn btn-success">รักษาหาย</button></a>


</center>
                </br></br></br>
</div>


@stop
