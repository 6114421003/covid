@extends("layouts.master")
 

@section('title') Covid-19 @stop


@section('content')
@stop
