
<?php $__env->startSection('title'); ?> Covid-19 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<center><h1>ยอดผู้ติดเชื้อ Covid-19 ในประเทศไทย</h1>   </center>
<br>

<div class="panel panel-default">
<center>
    <a href="<?php echo e(URL::to('province/edit')); ?>" class="btn btn-success pull-right"><i class="fa fa-plus"></i> เพิ่มข้อมูล</a>
        <form action="<?php echo e(URL::to('province/search')); ?>" method="post" class="form-inline">
            <?php echo e(csrf_field()); ?>

            
         <input  type="text" name="q" class="form-control" placeholder="พิมพ์ชื่อสินค้าเพื่อค้นหา">
            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> ค้นหา</button>
        </form>
     
     
    </div>
 

    <table class="table table-bordered table-striped table-hover">
    
        <thead>
        <br>
        <tr>
            <td>ลำดับ</td>
            <td>จังหวัด</td>
            <td>ยอดสะสม</td>
            <td>กำลังรักษา</td>
            <td>หายป่วย</td>
            <td>เสียชีวิต</td>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->id); ?></td>
                <td><?php echo e($p->name); ?></td>
                <td><?php echo e($p->infe); ?></td>
                <td><?php echo e($p->cure); ?></td>
                <td><?php echo e($p->sick); ?></td>
                <td><?php echo e($p->died); ?></td>

                <td>
                <a href="<?php echo e(URL::to('province/edit/'.$p->id)); ?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                    <a href="#" class="btn btn-danger btn-delete" id-delete="<?php echo e($p->id); ?>"><i class="fa fa-trash-o"></i> ลบ</a>
                </td>
                <script>
                    $('.btn-delete').on('click', function() {
                        if(confirm("คุณต้องการลบข้อมูลสินค้าหรือไม่?")) {
                            var url = "<?php echo e(URL::to('province/remove')); ?>" + '/' + $(this).attr('id-delete');
                            window.location.href = url;
                        }
                        
                    });
                </script>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
    </table>

    <?php echo e($provinces->links()); ?>

            <br>
   <center> <a href="provinceJS"button type="button" class="btn btn-danger">ยอดสะสม</button></a>
    <a href="province1JS"button type="button" class="btn btn-success">หายป่วย</button></a></center>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\PP\work\covid19\resources\views/province/index.blade.php ENDPATH**/ ?>