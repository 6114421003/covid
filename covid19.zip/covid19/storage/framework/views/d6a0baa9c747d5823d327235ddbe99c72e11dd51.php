

<?php $__env->startSection('title'); ?> 
    จังหวัดที่มีผู้ติดเชื้อCovid-19 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<canvas id="myChart" width="40" height="20"></canvas>
<script>
    $(function(){
        //get the pie chart canvas
        var cData = JSON.parse(`<?php echo $chart_data; ?>`);
        var ctx = $("#myChart");
   
        //pie chart data
        var data = {
          labels: cData.label,
          datasets: [
            {
              label: "",
              data: cData.data,
              backgroundColor: [
                "#FF0000",
                "#ff8000",
                "#ffff00",
                "#bfff00",
                "#40ff00",
                "#00ffff",
                "#0000ff",
                "#8000ff",
                "#bf00ff",
                "#ff00ff",
                "#ff00bf",
                "#ff0040",
              ],
              borderColor: [
                "#CDA776",
                "#989898",
                "#CB252B",
                "#E39371",
                "#1D7A46",
                "#F4A460",
                "#CDA776",
              ],
              borderWidth: [1, 1, 1, 1, 1,1,1]
            }
          ]
        };
   
        //options
        var options = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "กราฟแสดงยอดผู้ติดเชื้อในเเต่ละจังหวัด",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: true,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          }
        };
   
        //create Pie Chart class object
        var chart1 = new Chart(ctx, {
          type: "bar",
          data: data,
          options: options
        });
   
    });
    
  </script>
  
       <center> <a href="province"button type="button" class="btn btn-danger">ย้อนกลับ</button></a></center>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\PP\work\covid19\resources\views/provinceJS.blade.php ENDPATH**/ ?>