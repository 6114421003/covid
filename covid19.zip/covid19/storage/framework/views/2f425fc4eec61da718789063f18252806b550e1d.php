
<?php $__env->startSection('title'); ?> Covid-19 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<center><h1>ยอดผู้ติดเชื้อ Covid-19 ในประเทศไทย</h1>
<br>

<div class="panel panel-default">
    <?php echo Form::model($province, array('action' => 'ProvinceController@update','method' => 'post', 'enctype' => 'multipart/form-data')); ?>

    <input type="hidden" name="id" value="<?php echo e($province->id); ?>">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="panel-heading">
        <div class="panel-title"><strong>แก้ไขข้อมูล Covie-19</strong></div>
    </div>
    <div class="panel-body">
        <table>

            <tr>
                <td><?php echo e(Form::label('name', 'จังหวัด')); ?></td>
                <td><?php echo e(Form::text('name', Request::old('name'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('infe', 'ยอดสะสม')); ?></td>
                <td><?php echo e(Form::text('infe', Request::old('infe'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('cure', 'กำลังรักษา')); ?></td>
                <td><?php echo e(Form::text('cure', Request::old('cure'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('sick', 'หายป่วย')); ?></td>
                <td><?php echo e(Form::text('sick', Request::old('sick'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('died', 'เสียชีวิต')); ?></td>
                <td><?php echo e(Form::text('died', Request::old('died'), ['class' => 'form-control'])); ?></td>
            </tr>
           
        </table>
    </div>
    <br>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    <?php echo Form::close(); ?>

</div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\PP\work\covid19\resources\views/province/edit.blade.php ENDPATH**/ ?>