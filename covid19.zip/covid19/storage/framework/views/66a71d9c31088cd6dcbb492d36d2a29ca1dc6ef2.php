
<?php $__env->startSection('title'); ?> Covid-19 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<center><h1>ยอดผู้ติดเชื้อ Covid-19 ในจังหวัดจันทบุรี</h1>
<br>

<div class="panel panel-default">
    <?php echo Form::model($covid, array('action' => 'CovidController@update','method' => 'post', 'enctype' => 'multipart/form-data')); ?>

    <input type="hidden" name="id" value="<?php echo e($covid->id); ?>">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="panel-heading">
        <div class="panel-title"><strong>แก้ไขข้อมูล Covie-19</strong></div>
    </div>
    <div class="panel-body">
        <table>

            <tr>
                <td><?php echo e(Form::label('dis', 'อำเภอ')); ?></td>
                <td><?php echo e(Form::text('dis', Request::old('dis'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('ndis', 'จำนวนคนที่อยู่ในอำเภอ')); ?></td>
                <td><?php echo e(Form::text('ndis', Request::old('ndis'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('piwc', 'ติดเชื้อสะสม')); ?></td>
                <td><?php echo e(Form::text('piwc', Request::old('piwc'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('cure', 'รักษาหาย')); ?></td>
                <td><?php echo e(Form::text('cure', Request::old('cure'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('vp', 'คนฉีดวัคซีน')); ?></td>
                <td><?php echo e(Form::text('vp', Request::old('vp'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('nvp', 'คนที่ยังไม่ได้ฉีดวัคซีน')); ?></td>
                <td><?php echo e(Form::text('nvp', Request::old('nvp'), ['class' => 'form-control'])); ?></td>
            </tr>
            <tr>
                <td><?php echo e(Form::label('die', 'เสียชีวิต')); ?></td>
                <td><?php echo e(Form::text('die', Request::old('die'), ['class' => 'form-control'])); ?></td>
            </tr>
           
        </table>
    </div>
    <br>
    <div class="panel-footer">
      <button type="http://127.0.0.1:8000/covid" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    <?php echo Form::close(); ?>

</div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\codemay\covid19\resources\views/covid/edit.blade.php ENDPATH**/ ?>