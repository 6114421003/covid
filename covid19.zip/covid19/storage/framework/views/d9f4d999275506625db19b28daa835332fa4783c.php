

<?php $__env->startSection('title'); ?> 
    Covid-19 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<canvas id="myChart" width="40" height="20"></canvas>
<script>
    $(function(){
        //get the pie chart canvas
        var cData = JSON.parse(`<?php echo $chart_data; ?>`);
        var ctx = $("#myChart");
   
        //pie chart data
        var data = {
          labels: cData.label,
          datasets: [
            {
              label: "",
              data: cData.data,
              backgroundColor: [
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",
                "#FF0000",

              ],
              borderColor: [

              ],
              borderWidth: [1, 1, 1, 1, 1,1,1]
            }
          ]
        };
   
        //options
        var options = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "กราฟแสดงยอดผู้ติดเชื้อในเเต่ละอำเภอ",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: true,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          }
        };
   
        //create Pie Chart class object
        var chart1 = new Chart(ctx, {
          type: "bar",
          data: data,
          options: options
          
        });
        
        
   
    });
    
  </script>
  
  
       <center> <a href="covid"button type="button" class="btn btn-danger">ย้อนกลับ</button></a></center>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\codemay\covid19\resources\views/covidJS.blade.php ENDPATH**/ ?>