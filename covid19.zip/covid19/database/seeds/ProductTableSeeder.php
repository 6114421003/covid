<?php

use Illuminate\Database\Seeder;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('product')->insert(array(

            [
            
            'name' => 'Nakamichi NMCE110-BK',   
            'category_id' => 1,            
            'unit_price' => 490,           
            'cost_price' => 250,            
            'stock_qty' => 5,           
            'img_path' => 'img/01.jpg',
            
            ],
                        
            ));           
    }
}