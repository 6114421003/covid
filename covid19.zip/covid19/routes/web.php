<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'CovidController@index');


Route::get('/covid', 'CovidController@index');
Route::post('/covid/search', 'CovidController@search');
Route::get('/covid/search', 'CovidController@search');

Route::get('/covid/edit/{id?}', 'CovidController@edit');
Route::post('/covid/update', 'CovidController@update');
Route::post('/covid/insert', 'CovidController@insert');
Route::get('/covid/remove/{id}', 'CovidController@remove');


Route::get('covidJS', [App\Http\Controllers\covidJSController::class, 'index']);
Route::get('covid2JS', [App\Http\Controllers\covid2JSController::class, 'index']);
Route::get('covid3JS', [App\Http\Controllers\covid3JSController::class, 'index']);

