<?php

namespace App\Http\Controllers;

use App\Research;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Covid3JSController extends Controller
{
    
        public function index(){
            $researcher = DB::table('covid')
            ->select(DB::raw('die'), DB::raw("dis"))
            ->where('dis', '<>', 2)
            ->get();
     
            $data = [];
     
             foreach($researcher as $row){
                 $data['label'][] = $row->dis;
                 $data['data'][] = (int)$row->die;
             }
             $data['chart_data'] = json_encode($data);
             return view('covid3JS',$data);
             
     
     
         }
         
     
    
}
