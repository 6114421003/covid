<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Covid;
use App\Category;

class CovidController extends Controller
{
    public function index() {
        $covids = Covid::paginate();
        return view('covid/index', compact('covids'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $covid = Covid::where('id', $id)->first();
            return view('covid/edit')
                ->with('covid', $covid)
                ->with('categories', $categories);
        } else {
            return view('covid/add')
                ->with('categories', $categories);
        }
    }

        public function update(Request $request) {
            $rules = array(
                'dis' => 'required',

    
            );
            $messages = array(
                'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
                'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
            );
            $id = $request->input('id');
            $validator = Validator::make($request->all(), $rules, $messages);
            if ($validator->fails()) {
                return redirect('covid/edit/'.$id)
                    ->withErrors($validator)
                    ->withInput();
            }
            $covid = Covid::find($id);
            $covid->dis = $request->input('dis');
            $covid->ndis = $request->input('ndis');
            $covid->piwc = $request->input('piwc');
            $covid->cure = $request->input('cure');
            $covid->vp = $request->input('vp');
            $covid->nvp = $request->input('nvp');
            $covid->die = $request->input('die');
            $covid->save();
            return redirect('covid')
                ->with('ok', true)
                ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
        
        }

    public function insert(Request $request) {
        $rules = array(
            'dis' => 'required',

        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('covid/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $covid = new Covid();
        $covid->dis = $request->input('dis');
        $covid->ndis = $request->input('ndis');
        $covid->piwc = $request->input('piwc');
        $covid->cure = $request->input('cure');
        $covid->vp = $request->input('vp');
        $covid->nvp = $request->input('nvp');
        $covid->die = $request->input('die');
        $covid->save();
        return redirect('covid')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    }
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $covids = Covid::where('dis', 'like', '%'.$query.'%')
                ->orWhere('die', 'like', '%'.$query.'%')
                ->paginate();

        } else {
            $covids = Covid::paginate();
        }
        return view('covid/index', compact('covids'));

    }

    public function remove($id) {
        Covid::find($id)->delete();
        return redirect('covid')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
    

 }