<?php

namespace App\Http\Controllers;

use App\Research;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Covid2JSController extends Controller
{
    public function index(){
        $researcher = DB::table('covid')
        ->select(DB::raw('cure'), DB::raw("dis"))
        ->where('dis', '<>', 2)
        ->get();
 
        $data = [];
 
         foreach($researcher as $row){
             $data['label'][] = $row->dis;
             $data['data'][] = (int)$row->cure;
         }
         $data['chart_data'] = json_encode($data);
         return view('covid2JS',$data);
         
 
 
     }
     
 }
