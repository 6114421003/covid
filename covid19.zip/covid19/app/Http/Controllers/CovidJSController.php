<?php

namespace App\Http\Controllers;

use App\Research;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CovidJSController extends Controller
{
    public function index(){
        $researcher = DB::table('covid')
        ->select(DB::raw('piwc'), DB::raw("dis"))
        ->where('dis',   '<>', 10  )
        ->get();
 
        $data = [];
 
         foreach($researcher as $row){
             $data['label'][] = $row->dis;

             $data['data'][] = (int)$row->piwc;

         }
         $data['chart_data'] = json_encode($data);
         return view('covidJS',$data);
         
 
 
     }
     
 }
